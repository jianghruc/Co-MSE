function [H_star,iter,W1,W2,L1,L2]=our_method(X,K,C,lambda,r)

V=length(X); 
n=size(X{1},1); 
W1=cell(V,1);
W2=cell(V,1);
L1=cell(V,1);
L2=cell(V,1);

for i=1:V
    W1{i}=Gausskernel(X{i});
    A=KNN_matrix(W1{i},K); 
    W2{i}=Gausskernel(A); 
    for k=1:n
        for j=1:n
            a=0;
            for t=1:n
                if A(k,t)~=0 && A(j,t)~=0
                    a=1;
                    break
                end
            end
            if a==0
                W2{i}(k,j)=0;
            end
        end
    end
    W2{i}=(W2{i}+W2{i}')/2;

    D=diag(sqrt(sum(A,2).^(-1)));
    L1{i}=eye(n)-D*A*D;
    L1{i}=(L1{i}+L1{i}')/2;

    D=diag(sqrt(sum(W2{i},2).^(-1)));
    L2{i}=eye(n)-D*W2{i}*D; 
    L2{i}=(L2{i}+L2{i}')/2; 
end

u=ones(V,1)/V; 
H_star=zeros(n,C);
obj1=0;

for iter=1:30 

L11=zeros(n);
for i=1:V
    L11=L11+((u(i))^r)*L1{i};
end

LL=L11-lambda*(H_star*H_star');
[H1,~]=eigs(LL, C, 'smallestreal');

L22=zeros(n);
for i=1:V
    L22=L22+((u(i))^r)*L2{i};
end

LL=L22-lambda*(H_star*H_star');
[H2,~]=eigs(LL, C, 'smallestreal');

L_star=H1*H1'+H2*H2';
[H_star,~]=eigs(L_star, C, 'lm');

a=0;
for i=1:V
    a=a+(1/(trace(H1'*L1{i}*H1)+trace(H2'*L2{i}*H2)))^(1/(r-1));
end
for i=1:V
    u(i)=(1/(trace(H1'*L1{i}*H1)+trace(H2'*L2{i}*H2)))^(1/(r-1))/a;
end

obj2=obj1;
obj1=trace(H1'*L11*H1)+trace(H2'*L22*H2)-lambda*(trace(H1*H1'*(H_star*H_star'))+trace(H2*H2'*(H_star*H_star')));
if (abs(obj1-obj2)/abs(obj1))<=1e-4
    break
end

end

for i=1:n
    a=0;
    for j=1:C
        a=a+H_star(i,j)^2;
    end
    a=sqrt(a);
    H_star(i,:)=H_star(i,:)/a;
end

end


