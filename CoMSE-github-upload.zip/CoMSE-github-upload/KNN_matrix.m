function [A]=KNN_matrix(D,K)

n=size(D);
A=D;
[~,index]=sort(D,1,'descend'); 
KNNindex = index(1:K,:);
for i=1:n
    for j=1:n
        a=0;
        for m=1:K
            if KNNindex(m,i)==j || KNNindex(m,j)==i
                a=1;
                break
            end
        end
        if a==0
            A(i,j)=0;
        end
    end
end

A=(A+A')/2;
end

