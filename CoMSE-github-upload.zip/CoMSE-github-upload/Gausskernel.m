function [A] = Gausskernel(X)

n=size(X,1);
A=zeros(n);

X_mean=zeros(1,size(X,2));
sigma=0;
for i=1:n
    X_mean=X_mean+X(i,:);
end
X_mean=X_mean/n;
for i=1:n
    sigma=sigma+(norm(X(i,:)-X_mean))^2;
end
sigma=sigma/(n-1);

for i=1:n
    for j=1:n
        A(i,j)=exp(-norm(X(i,:)-X(j,:))^2/(2*sigma));
    end
    A(i,i)=0;  
end
A=(A+A')/2;
end

