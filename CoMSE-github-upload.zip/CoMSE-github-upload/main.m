function [result]=main(dataset)
  switch dataset
      case 'BBC'
 addpath('./datasets/BBC')
 load('preprocesseddata.mat')
  case 'NGs'
 addpath('./datasets/NGs')
 load('preprocesseddata.mat')
  case '100leaves'
 addpath('./datasets/100leaves')
 load('preprocesseddata.mat')
      case 'MSRCv1'
 addpath('./datasets/MSRCv1')
load('preprocesseddata.mat')
      case 'BBCsport'
 addpath('./datasets/BBCsport')
load('preprocesseddata.mat')
  end



C=length(unique(groundtruth));  
num = size(X{1},1);
K=10;       
lambda=10;   
r=2;        

[H,iter]=our_method(X,K,C,lambda,r);

N=20;
result1=zeros(N,1);
result2=zeros(N,1);
result3=zeros(N,1);

for i=1:N
result(i,:)=kmedoids(H,C);
end

for i=1:N
    
result1(i) = ARI(groundtruth,result(i,:));
result2(i)=Cal_NMI(groundtruth,result(i,:));
result3(i)=Accuracy(result(i,:),groundtruth);

end

result_kmedoids(1) = mean(result1)
result_kmedoids(2) = mean(result2)
result_kmedoids(3) = mean(result3)



