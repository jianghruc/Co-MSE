X=fea';
[X]=NormalizeData(X);
groundtruth=gt;
save preprocesseddata X groundtruth;