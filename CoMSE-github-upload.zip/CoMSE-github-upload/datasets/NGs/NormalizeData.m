function [X] = NormalizeData(X)
n=size(X{1},1);
v = length(X); 
for i = 1:v
    if issparse(X{i})
        X{i} = full(X{i});
    end
   for j=1:n
       X{i}(j,:)=X{i}(j,:)/sqrt(X{i}(j,:)*X{i}(j,:)');
   end
end

