
X=data';
for i=1:3
    X{i}=X{i}';
end
[X]=NormalizeData(X);
groundtruth=truelabel{1};
save preprocesseddata X groundtruth;

