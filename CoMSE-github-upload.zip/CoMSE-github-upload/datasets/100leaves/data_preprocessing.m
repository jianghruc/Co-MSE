X=data';
for i=1:3
    X{i}=X{i}';
end
[X] = NormalizeData(X);
save preprocesseddata X groundtruth;