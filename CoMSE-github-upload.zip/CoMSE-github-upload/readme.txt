1. Introduction

This is the code for the paper 'Co-Regularized Optimal High-Order Graph Embedding for
Multi-View Clustering' accepted by Pattern Recognition. 
If you use our code, please cite our paper:  
Co-Regularized Optimal High-Order Graph Embedding for
Multi-View Clustering

 
Co-MSE：By integrating the first-order and second-order similarities, the local structure is preserved, while an optimized
embedding representation for multi-view data is obtained simultaneously through coregularization.


2. Code Usage

To get the results, run the 'main.m' file directly in the  directory. 
You can specify different dataset choices.

The proposed method has two parameters λ and r,  users can specify them according the requirements.
We fixed λ = 10, r = 2 for the experiment.











